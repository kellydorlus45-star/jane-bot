function resample(rows, mins){
  if(mins===1) return rows; const ms=mins*60000,map=new Map();
  for(const r of rows){const t=Date.parse(r.time);if(!Number.isFinite(t))continue;const k=Math.floor(t/ms)*ms;let b=map.get(k);if(!b)b={time:new Date(k).toISOString(),open:r.open,high:r.high,low:r.low,close:r.close,count:0};b.high=Math.max(b.high,r.high);b.low=Math.min(b.low,r.low);b.close=r.close;b.count++;map.set(k,b)}
  return [...map.values()].filter(x=>x.count>=Math.max(1,Math.floor(mins*.8))).sort((a,b)=>Date.parse(a.time)-Date.parse(b.time));
}
function resampleHours(rows,hours){return resample(rows,hours*60);}
function hashHex(str){let h=2166136261;for(let i=0;i<str.length;i++){h^=str.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16).padStart(8,'0').toUpperCase();}
module.exports = async function handler(req,res){
 try{
  const q=req.query||{},symbol=String(q.symbol||'EUR/USD').toUpperCase(),interval=String(q.interval||'15min'),mode=String(q.mode||'forex'),anchor=String(q.anchor||'');
  if(!/^[A-Z]{3}\/[A-Z]{3}$/.test(symbol))return res.status(400).json({error:'Invalid symbol'});
  if(!['forex','binary'].includes(mode))return res.status(400).json({error:'Invalid mode'});
  const allowed=new Set(['1min','2min','3min','5min','10min','15min','30min','45min','1h','2h','4h','5h','8h','1day','1week','1month']);
  if(!allowed.has(interval))return res.status(400).json({error:'Invalid interval'});
  if(['5s','10s','15s','30s'].includes(interval))return res.status(400).json({error:'Second candles are not available from the current data source.'});
  const apiKey=process.env.TWELVEDATA_API_KEY;if(!apiKey)return res.status(500).json({error:'TWELVEDATA_API_KEY is not configured'});
  const base=['2min','3min','5min','10min','5h'].includes(interval)?(interval==='5h'?'1h':'1min'):interval;
  const url=new URL('https://api.twelvedata.com/time_series');url.searchParams.set('symbol',symbol);url.searchParams.set('interval',base);url.searchParams.set('outputsize','5000');url.searchParams.set('apikey',apiKey);
  const upstream=await fetch(url.toString(),{headers:{accept:'application/json'},cache:'no-store'});const text=await upstream.text();let data={};
  try{data=text?JSON.parse(text):{}}catch{return res.status(502).json({error:`Invalid response from market data provider (${upstream.status})`})}
  if(!upstream.ok||data.status==='error')return res.status(upstream.status>=400?upstream.status:502).json({error:data.message||data.code||'Market data error'});
  let values=(data.values||[]).map(v=>({time:v.datetime,open:+v.open,high:+v.high,low:+v.low,close:+v.close})).filter(v=>Object.values(v).every(Number.isFinite)).reverse();
  if(['2min','3min','5min','10min'].includes(interval))values=resample(values,Number(interval.replace('min','')));
  if(interval==='5h')values=resampleHours(values,5);
  if(values.length<40)return res.status(422).json({error:'Not enough candles'});
  let end=values.length-2;const anchorMs=Date.parse(anchor);if(Number.isFinite(anchorMs)){for(let i=values.length-1;i>=0;i--){const t=Date.parse(values[i].time);if(Number.isFinite(t)&&t<=anchorMs){end=i;break}}}
  const closed=values.slice(0,end+1),c=closed.slice(-120);if(c.length<30)return res.status(422).json({error:'Not enough closed candles'});
  const closes=c.map(x=>x.close);
  const ema=(arr,n)=>{const k=2/(n+1);let e=arr[0];for(let i=1;i<arr.length;i++)e=arr[i]*k+e*(1-k);return e};
  const rsi=(arr,n=14)=>{let g=0,l=0;for(let i=1;i<=n;i++){const d=arr[i]-arr[i-1];g+=Math.max(d,0);l+=Math.max(-d,0)}g/=n;l/=n;for(let i=n+1;i<arr.length;i++){const d=arr[i]-arr[i-1];g=(g*(n-1)+Math.max(d,0))/n;l=(l*(n-1)+Math.max(-d,0))/n}return l===0?100:100-(100/(1+g/l))};
  const atr=()=>{const tr=[];for(let i=1;i<c.length;i++){const x=c[i],p=c[i-1];tr.push(Math.max(x.high-x.low,Math.abs(x.high-p.close),Math.abs(x.low-p.close)))}return tr.slice(-14).reduce((a,b)=>a+b,0)/Math.min(14,tr.length)};
  const last=c[c.length-1],prev=c[c.length-2],fast=ema(closes.slice(-80),9),slow=ema(closes.slice(-80),21),rv=rsi(closes,14),a=atr();let score=0,reasons=[];
  if(fast>slow){score++;reasons.push('EMA')}else if(fast<slow){score--;reasons.push('EMA')}
  if(rv>55){score++;reasons.push('RSI')}else if(rv<45){score--;reasons.push('RSI')}
  if(last.close>prev.close){score++;reasons.push('Momentum')}else if(last.close<prev.close){score--;reasons.push('Momentum')}
  let signal=score>=2?'BUY':score<=-2?'SELL':'WAIT';if(mode==='binary')signal=score>=2?'CALL':score<=-2?'PUT':'WAIT';
  const digits=symbol.endsWith('/JPY')?3:5,round=n=>Number(n.toFixed(digits));let sl=null,tp=null;
  if(mode==='forex'&&signal!=='WAIT'){const look=c.slice(-12),lo=Math.min(...look.map(x=>x.low)),hi=Math.max(...look.map(x=>x.high));if(signal==='BUY'){sl=round(Math.min(lo,last.close-a*.15));tp=round(last.close+(last.close-sl)*2)}else{sl=round(Math.max(hi,last.close+a*.15));tp=round(last.close-(sl-last.close)*2)}}
  const snapshot=`${symbol}|${interval}|${last.time}|${last.open}|${last.high}|${last.low}|${last.close}|${score}|${mode}`;const id=(hashHex(snapshot)+hashHex(snapshot.split('').reverse().join(''))).slice(0,16);
  res.setHeader('Cache-Control','no-store, max-age=0');return res.status(200).json({ok:true,mode,symbol,interval,signal,score,confidence:Math.round(Math.abs(score)/3*100),reasons,price:last.close,entry:last.close,stopLoss:sl,takeProfit:tp,candleTime:last.time,snapshotId:id,serverTime:new Date().toISOString()});
 }catch(e){return res.status(500).json({error:e?.message||'Server error'});}
};
