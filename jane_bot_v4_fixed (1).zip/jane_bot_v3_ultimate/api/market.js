export default async function handler(req, res) {
  try {
    const q = req.query || {};
    const symbol = String(q.symbol || 'EUR/USD').toUpperCase();
    const interval = String(q.interval || '15min');
    const requestedSize = Number(q.outputsize || 5000);
    const outputsize = Math.max(30, Math.min(Number.isFinite(requestedSize) ? Math.floor(requestedSize) : 5000, 5000));

    if (!/^[A-Z]{3}\/[A-Z]{3}$/.test(symbol)) {
      return res.status(400).json({ error: 'Invalid symbol' });
    }

    const allowed = new Set(['1min','5min','15min','30min','45min','1h','2h','4h','8h','1day','1week','1month']);
    if (!allowed.has(interval)) {
      return res.status(400).json({ error: `Invalid interval: ${interval}` });
    }

    const apiKey = process.env.TWELVEDATA_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: 'TWELVEDATA_API_KEY is not configured' });
    }

    const url = new URL('https://api.twelvedata.com/time_series');
    url.searchParams.set('symbol', symbol);
    url.searchParams.set('interval', interval);
    url.searchParams.set('outputsize', String(outputsize));
    url.searchParams.set('apikey', apiKey);

    const upstream = await fetch(url.toString(), {
      headers: { accept: 'application/json' },
      cache: 'no-store'
    });

    const text = await upstream.text();
    let data;
    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      return res.status(502).json({ error: `Invalid response from market data provider (${upstream.status})` });
    }

    if (!upstream.ok || data.status === 'error') {
      return res.status(upstream.status >= 400 ? upstream.status : 502).json({
        error: data.message || data.code || 'Market data provider error'
      });
    }

    if (!Array.isArray(data.values)) {
      return res.status(502).json({ error: 'Market data provider returned no candle data' });
    }

    res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    return res.status(200).json({
      symbol,
      interval,
      values: data.values
    });
  } catch (e) {
    return res.status(500).json({ error: e?.message || 'Market server error' });
  }
}
