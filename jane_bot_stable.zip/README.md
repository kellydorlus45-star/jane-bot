# Jane Bot — Stable Build

## Project structure
Keep these files at the repository root:

- `index.html`
- `vercel.json`
- `api/market.js`
- `api/signal.js`

The `api` folder must be at the root. Vercel automatically deploys files in a root `api` directory as Functions.

## Vercel
Keep the existing environment variable:

`TWELVEDATA_API_KEY`

Do not put the API key in `index.html`.

## What is included
- Forex + Binary
- Pair + Time Frame controls on Dashboard and Chart
- Binary operation time: 3–59 seconds, 1–59 minutes, 1–23 hours, 1 day
- Quick operation buttons from 3s through 1 day
- +/- controls and manual number entry
- Real OHLC data through `/api/market`
- Central signal endpoint `/api/signal` so matching devices can use the same closed-candle snapshot
- Signal fallback in the browser if the signal endpoint is temporarily unavailable
- Automatic update counter and 60-second countdown
- Interactive candlestick chart: drag, wheel zoom, pinch zoom, reset
- Candle menu: 100 / 200 / 300 / 500
- Signal animation, sound and mobile vibration
- Forex Entry / Stop Loss / Take Profit
- WIN / LOSS / Omit prompt after an actionable signal
- Pending history, delete one, clear all
- Dark/light theme and ES/EN/FR/PT
- No OTC

## Important
The operation expiry can be as short as 3 seconds, but the current market feed is minute-and-higher OHLC. The app does not invent second candles.
