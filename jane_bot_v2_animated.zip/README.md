# Jane Bot v2 — animado y revisado

Esta versión parte del diseño limpio anterior y añade:

- Animaciones en header, logo, tarjetas, botones, navegación, señal, historial y fondos.
- Selector de idioma ES / EN / FR / PT que traduce la interfaz visible y se guarda.
- Selector claro/oscuro que se guarda.
- Expiración de binarias con **número + unidad**: segundos, minutos, horas o días.
- Límites claros: 1–59 segundos, 1–59 minutos, 1–23 horas, 1 día.
- Time Frame separado de la expiración.
- Forex inicia en 15 min; Binarias en 1 min.
- Los intervalos que Twelve Data no entrega directamente se agrupan desde datos de 1 minuto/1 hora cuando es técnicamente posible.
- Los intervalos de segundos se dejan visibles pero no inventan datos: se avisa que la fuente actual no entrega velas de segundos.
- Actualización automática cada 60 segundos.
- El botón Generar señal permanece bloqueado hasta tener suficientes velas.
- Sonido y vibración al generar señal.
- Historial guarda también la expiración seleccionada.
- Sin interfaz OTC.
- Mantiene `/api/market` y la clave del servidor no se expone en el navegador.

IMPORTANTE:
La interfaz de expiración es la duración que el usuario elige para una operación binaria; no significa que la fuente de mercado entregue velas de esa duración. El Time Frame y la expiración son controles diferentes.
