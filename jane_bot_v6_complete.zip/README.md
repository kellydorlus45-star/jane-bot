# Jane Bot V6 — Complete

## Deploy structure
Keep this exact structure at the repository root:

- index.html
- vercel.json
- api/market.js
- api/signal.js

Do not put these inside another nested folder when importing the project into Vercel.

## Environment variable
Keep the existing Vercel variable:
`TWELVEDATA_API_KEY`

Never place the key in index.html.

## Included
- Forex + Binary
- Currency pair + Time Frame controls on Dashboard and Chart
- Binary expiry: 3–59 seconds, 1–59 minutes, 1–23 hours, 1 day
- +/- controls and quick expiry buttons
- Real OHLC data through the server endpoint
- Automatic update counter + countdown
- Interactive candlestick chart: drag, wheel zoom, pinch zoom, reset
- Candle-count menu: 100 / 200 / 300 / 500
- Signal animation, sound and vibration
- Forex Entry / Stop Loss / Take Profit
- WIN / LOSS / Omit result prompt
- Pending history + delete one + clear all
- Deterministic snapshot signal logic
- Signal endpoint fallback so a temporary /api/signal 404 does not break signal generation
- Dark/light theme and ES/EN/FR/PT language

## Important data note
The current Twelve Data source provides minute-and-higher OHLC intervals, not second candles. The binary operation expiry can be 3–59 seconds, but second-candle chart/timeframe data is not invented. If a 5s/10s/15s/30s candle timeframe is selected, the app explains that the current source does not provide those candles.
