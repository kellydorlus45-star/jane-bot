const ALLOWED = new Set(['1min','5min','15min','30min','45min','1h','2h','4h','8h','1day','1week','1month']);
const SYMBOL_RE = /^[A-Z]{3}\/[A-Z]{3}$/;

function send(res, status, body) {
  res.status(status).setHeader('Content-Type', 'application/json; charset=utf-8');
  res.end(JSON.stringify(body));
}
function rowsFromValues(values) {
  return (values || []).map(v => ({
    time: v.datetime || v.time || v.date,
    open: Number(v.open), high: Number(v.high), low: Number(v.low), close: Number(v.close)
  })).filter(x => [x.open,x.high,x.low,x.close].every(Number.isFinite)).sort((a,b)=>Date.parse(a.time)-Date.parse(b.time));
}
function resample(rows, minutes) {
  if (minutes === 1) return rows;
  const ms = minutes * 60000, map = new Map();
  for (const r of rows) {
    const t = Date.parse(r.time); if (!Number.isFinite(t)) continue;
    const k = Math.floor(t/ms)*ms;
    let b = map.get(k);
    if (!b) b = {time:new Date(k).toISOString(),open:r.open,high:r.high,low:r.low,close:r.close,count:0};
    b.high=Math.max(b.high,r.high); b.low=Math.min(b.low,r.low); b.close=r.close; b.count++;
    map.set(k,b);
  }
  return [...map.values()].filter(x=>x.count>=Math.max(1,Math.floor(minutes*.8))).sort((a,b)=>Date.parse(a.time)-Date.parse(b.time));
}
function resampleHours(rows, hours) {
  const ms = hours*3600000, map = new Map();
  for (const r of rows) {
    const t = Date.parse(r.time); if (!Number.isFinite(t)) continue;
    const k = Math.floor(t/ms)*ms;
    let b = map.get(k);
    if (!b) b = {time:new Date(k).toISOString(),open:r.open,high:r.high,low:r.low,close:r.close,count:0};
    b.high=Math.max(b.high,r.high); b.low=Math.min(b.low,r.low); b.close=r.close; b.count++;
    map.set(k,b);
  }
  return [...map.values()].filter(x=>x.count>=Math.max(1,hours-1)).sort((a,b)=>Date.parse(a.time)-Date.parse(b.time));
}
function ema(a,n){const k=2/(n+1);let e=a[0];for(let i=1;i<a.length;i++)e=a[i]*k+e*(1-k);return e;}
function rsi(a,n=14){let g=0,l=0;for(let i=1;i<=n;i++){let d=a[i]-a[i-1];g+=Math.max(d,0);l+=Math.max(-d,0)}g/=n;l/=n;for(let i=n+1;i<a.length;i++){let d=a[i]-a[i-1];g=(g*(n-1)+Math.max(d,0))/n;l=(l*(n-1)+Math.max(-d,0))/n}return l===0?100:100-(100/(1+g/l));}
function makeSignal(rows,symbol,interval,mode,anchor){
  let c = rows.filter(r => !anchor || Date.parse(r.time) < Date.parse(anchor));
  if(c.length>1)c=c.slice(0,-1); // latest returned candle may still be forming
  if(c.length<40) throw new Error('No hay suficientes velas cerradas.');
  c=c.slice(-120);
  const closes=c.map(x=>x.close), last=c[c.length-1], prev=c[c.length-2];
  const fast=ema(closes.slice(-80),9), slow=ema(closes.slice(-80),21), rv=rsi(closes,14);
  const tr=[];for(let i=1;i<c.length;i++){const x=c[i],p=c[i-1];tr.push(Math.max(x.high-x.low,Math.abs(x.high-p.close),Math.abs(x.low-p.close)))}
  const atr=tr.slice(-14).reduce((a,b)=>a+b,0)/Math.min(14,tr.length);
  let score=0,reasons=[];
  if(fast>slow){score++;reasons.push('EMA')}else if(fast<slow){score--;reasons.push('EMA')}
  if(rv>55){score++;reasons.push('RSI')}else if(rv<45){score--;reasons.push('RSI')}
  if(last.close>prev.close){score++;reasons.push('Momentum')}else if(last.close<prev.close){score--;reasons.push('Momentum')}
  let direction=score>=2?'BUY':score<=-2?'SELL':'WAIT'; if(mode==='binary')direction=score>=2?'CALL':score<=-2?'PUT':'WAIT';
  const digits=symbol.endsWith('/JPY')?3:5, round=n=>Number(n.toFixed(digits));
  let sl=null,tp=null;
  if(mode==='forex'&&direction!=='WAIT'){
    const look=c.slice(-12),lo=Math.min(...look.map(x=>x.low)),hi=Math.max(...look.map(x=>x.high));
    if(direction==='BUY'){sl=round(Math.min(lo,last.close-atr*.15));tp=round(last.close+(last.close-sl)*2)}
    else {sl=round(Math.max(hi,last.close+atr*.15));tp=round(last.close-(sl-last.close)*2)}
  }
  const snap=`${symbol}|${interval}|${last.time}|${last.open}|${last.high}|${last.low}|${last.close}|${score}|${mode}`;
  let hash=0;for(let i=0;i<snap.length;i++)hash=((hash<<5)-hash)+snap.charCodeAt(i)|0;
  const snapshotId=(Math.abs(hash).toString(16).padStart(8,'0')+last.time.replace(/\D/g,'')).slice(0,16).toUpperCase();
  return {ok:true,mode,symbol,interval,signal:direction,score,confidence:Math.round(Math.abs(score)/3*100),reasons,price:last.close,entry:last.close,stopLoss:sl,takeProfit:tp,candleTime:last.time,snapshotId,serverTime:new Date().toISOString()};
}
module.exports = async (req,res)=>{
  try{
    if(req.method!=='GET')return send(res,405,{error:'Method not allowed'});
    const q=req.query||{}, symbol=String(q.symbol||'').toUpperCase(), interval=String(q.interval||'1min'), mode=String(q.mode||'forex'), anchor=String(q.anchor||'');
    if(!process.env.TWELVEDATA_API_KEY)return send(res,500,{error:'TWELVEDATA_API_KEY no está configurada en Vercel.'});
    if(!SYMBOL_RE.test(symbol))return send(res,400,{error:'Símbolo inválido.'});
    if(!ALLOWED.has(interval) && !['2min','3min','10min','5h'].includes(interval))return send(res,400,{error:'Time Frame no soportado.'});
    let baseInterval=interval, baseSize=5000, transform=null;
    if(['2min','3min','5min','10min'].includes(interval)){baseInterval='1min';transform=Number(interval.replace('min',''));}
    if(interval==='5h'){baseInterval='1h';transform=5;}
    const url=new URL('https://api.twelvedata.com/time_series');url.searchParams.set('symbol',symbol);url.searchParams.set('interval',baseInterval);url.searchParams.set('outputsize',String(baseSize));url.searchParams.set('timezone','UTC');url.searchParams.set('apikey',process.env.TWELVEDATA_API_KEY);
    const upstream=await fetch(url,{cache:'no-store'}), text=await upstream.text();let data;try{data=JSON.parse(text)}catch{return send(res,502,{error:'La fuente devolvió una respuesta no válida.'})}
    if(!upstream.ok||data.status==='error'||data.code)return send(res,upstream.status||502,{error:data.message||data.error||'No se pudieron obtener los datos.'});
    let rows=rowsFromValues(data.values);if(transform)rows=interval==='5h'?resampleHours(rows,5):resample(rows,transform);
    return send(res,200,makeSignal(rows,symbol,interval,mode,anchor));
  }catch(err){return send(res,500,{error:err?.message||'Error al generar la señal.'})}
};
